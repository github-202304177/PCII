from Classes.Assets.Asset import Asset
from Classes.Gclass import Gclass

class Commodity(Asset, Gclass):
    
    obj = dict()
    lst = list()
    path = "Data/online_broker.db"
    pos=0
    att = ['_code','_ticker', '_name', '_price']
    des = ['Code', 'Ticker', 'Name', 'Price']
    header = 'Commodities'
     
            
    available_assets = {
    'BZ=F': 'Brent Oil',
    'CC=F': 'Cocoa',
    'KC=F': 'Coffee',
    'HG=F': 'Copper',
    'ZC=F': 'Corn',
    'CT=F': 'Cotton',
    'CL=F': 'Crude Oil',
    'GC=F': 'Gold',
    'KE=F': 'Wheat',
    'HE=F': 'Lean Hogs',
    'LE=F': 'Live Cattle',
    'NG=F': 'Natural Gas',
    'ZO=F': 'Oat',
    'OJ=F': 'Orange Juice',
    'PA=F': 'Palladium',
    'ZR=F': 'Rice',
    'SI=F': 'Silver',
    'SB=F': 'Sugar'
    }

    def __init__(self, code = None, ticker = None, name = None, price = None):
        super().__init__(None, ticker)
        Commodity.obj[self._code] = self
        Commodity.lst.append(self._code)
        
