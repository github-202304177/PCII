import datetime
import requests
import pandas as pd

from Classes.Assets.Asset import Asset
from Classes.Gclass import Gclass

class Cryptocurrency(Asset, Gclass):
    
    obj = dict()
    lst = list()
    path = "Data/online_broker.db"
    pos = 0
    att = ['_code', '_ticker','_name', '_price']
    des = ['Code', 'Ticker', 'Name', 'Price']
    header = 'Cryptocurrencies'

    available_assets = {
    'BTC': 'Bitcoin',
    'ETH': 'Ethereum',
    'BNB': 'Binance Coin',
    'SOL': 'Solana',
    'USDC': 'USDC',
    'XRP': 'XRP',
    'DOGE': 'Dogecoin',
    'ADA': 'Cardano',
    'SHIB': 'Shiba Inu',
    'AVAX': 'Avalanche',
    'TRX': 'TRON',
    'DOT': 'Polkadot',
    'BCH': 'Bitcoin Cash',
    'LINK': 'Chainlink',
    'MATIC': 'Polygon',
    'NEAR': 'NEAR Protocol',
    'ICP': 'Internet Computer',
    'LTC': 'Litecoin'
    }
    
    def __init__(self, code = None, ticker = None, name = None, price = None):
        super().__init__(None, ticker)
        Cryptocurrency.obj[self._code] = self
        Cryptocurrency.lst.append(self._code)
    
    def update_price(self):
        symbol = self.ticker + "USDT"
        url = "https://api.binance.com/api/v3/ticker/price"
        params = {"symbol": symbol}
        response = requests.get(url, params=params)
        if not response.ok:
            raise AssertionError(response.json())
        data = response.json()
        self.price = float(data['price'])
        return

    def last_n_days_prices(symbol, n_days=10):
        url = "https://api.binance.com/api/v3/klines"
        end_time = pd.Timestamp.now()
        start_time = end_time - pd.Timedelta(days=n_days)
        start_time_ms = int(start_time.timestamp() * 1000)
        end_time_ms = int(end_time.timestamp() * 1000)
        params = {
            "symbol": symbol.upper() + "USDT",
            "interval": "1d", 
            "startTime": start_time_ms,
            "endTime": end_time_ms,
            "limit": 1000
        }
        response = requests.get(url, params=params)
        response.raise_for_status() 
        data = response.json()
        df = pd.DataFrame(data, columns=["timestamp", "open", "high", "low", "close", "volume", "close_time", "quote_asset_volume", "number_of_trades", "taker_buy_base_asset_volume", "taker_buy_quote_asset_volume", "ignore"])
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
        df.set_index("timestamp", inplace=True)
        df['close'] = pd.to_numeric(df['close'], errors='coerce')
        df.index.name = None
        return df[["close"]].round(2)


    
    