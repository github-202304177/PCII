import requests
import pandas as pd
from io import StringIO

from Classes.Assets.Asset import Asset
from Classes.Gclass import Gclass

class Stock(Asset, Gclass):
  
    obj = dict()
    lst = list()
    path = 'Data/online_broker.db'
    pos = 0
    att = ['_code', '_ticker','_name', '_price']
    des = ['Code', 'Ticker', 'Name', 'Price']
    header = 'Stocks'
    
    available_assets = {
    'AAPL': 'Apple Inc',
    'AMD': 'Advanced Micro Devices Inc',
    'AMZN': 'Amazon.com Inc',
    'CVX': 'Chevron Company',
    'COST': 'Costco',
    'DIS': 'Disney',
    'META': 'Meta',
    'MSFT': 'Microsoft Corp',
    'NFLX': 'Netflix',
    'NVDA': 'NVIDIA Corp',
    'TSLA': 'Tesla Inc',
    'GOOGL': 'Alphabet Inc',
    'JPM': 'JPMorgan Chase & Co',
    'JNJ': 'Johnson & Johnson',
    'V': 'Visa Inc',
    'MA': 'Mastercard Inc',
    'HD': 'Home Depot Inc',
    'UNH': 'UnitedHealth Group Inc',
    'PYPL': 'PayPal Holdings Inc',
    'BAC': 'Bank of America Corp'
    }
      
    def __init__(self, code = None, ticker = None, name = None, price = None):
        super().__init__(None, ticker)
        Stock.obj[self._code] = self
        Stock.lst.append(self._code)
        
    def get_holders(self):
        ticker = self.ticker
        holders_site = "https://finance.yahoo.com/quote/" + \
                        ticker + "/holders?p=" + ticker
        html_content = requests.get(holders_site, headers={'User-agent': 'Mozilla/5.0'}).text
        stringio_object = StringIO(html_content)
        tables = pd.read_html(stringio_object)
        table_names = ["Major Holders","Top Institutional Holders"]
        table_mapper = {key: val for key, val in zip(table_names, tables)}
        table_mapper["Major Holders"] = table_mapper["Major Holders"].iloc[1:]
        return table_mapper["Major Holders"], table_mapper["Top Institutional Holders"]

    def get_stats_valuation(self):
        ticker = self.ticker
        stats_site = "https://finance.yahoo.com/quote/" + ticker + \
                     "/key-statistics?p=" + ticker
        html_content= requests.get(stats_site, headers={'User-agent': 'Mozilla/5.0'}).text
        stringio_object = StringIO(html_content)
        tables = pd.read_html(stringio_object)
        tables = [table for table in tables if "Trailing P/E" in table.iloc[:,0].tolist()]
        table = tables[0].reset_index(drop = True)
        return table
        
    # Se chegarmos a fazer relatorios usamos esta função
    
    def get_stats(ticker):
        stats_site = "https://finance.yahoo.com/quote/" + ticker + "/key-statistics?p=" + ticker
        html_content= requests.get(stats_site, headers={'User-agent': 'Mozilla/5.0'}).text
        stringio_object = StringIO(html_content)
        tables = pd.read_html(stringio_object)
        tables = [table for table in tables[1:] if table.shape[1] == 2]
        if not tables:
            return pd.DataFrame()  # Return an empty DataFrame if no valid tables are found
        combined_table = pd.concat(tables, ignore_index=True)
        combined_table.columns = ["Attribute", "Value"]
        return combined_table