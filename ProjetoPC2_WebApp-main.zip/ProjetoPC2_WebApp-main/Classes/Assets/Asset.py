# Asset class is the mother class for the classes Commodity, Cryptocurrency, ETF and Stock.
# It allows their management and their objects' name and price regular updates.
# Each of those classe as an 'available_assets' dictionary that contains the name of all the trade
# assets of each asset type. The update_name method updates the name from there, given the ticker
# of the asset.
# The update_price method gets the real time price of an asset from the yahoo finance database online.
# This goes for all asset types except for cryptocurrency, because the real time prices for cryptos
# are pulled from the Binance online database.
# Every time a price of an asset is updated, it is written on the pricerecord attribute of each
# object, which as the from of a Panda dataframe.
# The attribute code of each object is automatically attributed for each asset type.
# To create an object only the ticker is needed, but due to the generic class good functioning
# it needs to be created with the argument code as None.
# For instance: bitcoin = Cryptocurrency(None, 'BTC')

import pandas as pd
import requests

class Asset:

    obj = dict()
    lst = list()
    pos = 0
    sortkey = ''
    auto_number = 1
    nkey = 1
    att = ['_code', '_ticker','_name', '_price']
    des = ['Code', 'Ticker', 'Name', 'Price']
    header = 'Assets'

    def __init__(self, code = None, ticker = None, name = None, price = None):
        super().__init__()
        
        if code == None:
            codes = self.__class__.getatlist('_code')
            if codes == []:
                code = str(1)
            else:
                code = str(max(map(int,self.__class__.getatlist('_code'))) + 1)
        
        self._code = str(code)
        self._ticker = str(ticker)
        self._name = None
        self._price = None
        self.update_name()
        self.update_price()
        
        Asset.obj[self._code] = self
        Asset.lst.append(self._code)
        
    @property
    def code(self):
        return self._code
    @code.setter
    def code(self, code):
        self._code = str(code)
        
    @property
    def ticker(self):
        return self._ticker
    @ticker.setter
    def ticker(self, ticker):
        self._ticker = str(ticker)
        
    @property
    def name(self):
        return self._name
    @name.setter
    def name(self, name):
        self._name = str(name)
    
    @property
    def price(self):
        return self._price
    @price.setter
    def price(self, price):
        self._price = float(round(eval(str(price)), 2))
    
    def update_name(self):
        self.name = self.__class__.available_assets[self.ticker]
    
    def update_price(self):
        site = f"https://query1.finance.yahoo.com/v8/finance/chart/{self.ticker}"
        params = {"interval": "1d", "events": "div,splits"}
        resp = requests.get(site, params=params, headers={'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'})
        if not resp.ok:
            raise AssertionError(resp.json())
        data = resp.json()
        self.price = data["chart"]["result"][0]["indicators"]["quote"][0]["close"][-1]
        return
    
    def last_n_days_prices(ticker, n_antes=10):
        headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
        interval = "1d"
        end_date = pd.Timestamp.now().strftime("%Y-%m-%d")
        start_date = (pd.Timestamp.now() - pd.Timedelta(days=n_antes)).strftime("%Y-%m-%d")
        site = "https://query1.finance.yahoo.com/v8/finance/chart/" + ticker       
        params = {"period1": int(pd.Timestamp(start_date).timestamp()), "period2": int(pd.Timestamp(end_date).timestamp()),
                  "interval": interval.lower(), "events": "div,splits"}
        resp = requests.get(site, params=params, headers=headers)
        if not resp.ok:
            raise AssertionError(resp.json())
        data = resp.json()
        frame = pd.DataFrame(data["chart"]["result"][0]["indicators"]["quote"][0])
        temp_time = data["chart"]["result"][0]["timestamp"]
        if interval != "1m":
            frame["close"] = data["chart"]["result"][0]["indicators"]["adjclose"][0]["adjclose"]   
            frame.index = pd.to_datetime(temp_time, unit="s")
            frame.index = frame.index.map(lambda dt: dt.floor("d"))
            frame["close"] = frame["close"].round(2)
            frame = frame[["open", "high", "low", "close", "volume"]]
        frame['ticker'] = ticker.upper()
        frame.index.name = None
        return frame[['close']]