from Classes.Assets.Asset import Asset
from Classes.Gclass import Gclass

class ETF(Asset, Gclass):
    
    obj = dict()
    lst = list()
    path = "Data/online_broker.db"
    pos = 0
    att = ['_code','_ticker', '_name', '_price']
    des = ['Code', 'Ticker', 'Name', 'Price']
    header = 'ETFs'
    
    available_assets = {
    'SPY': 'SPDR S&P 500 ETF Trust',
    'IVV': 'iShares Core S&P 500 ETF',
    'VOO': 'Vanguard S&P 500 ETF',
    'VTI': 'Vanguard Total Stock Market ETF',
    'QQQ': 'Invesco QQQ Trust Series I',
    'VEA': 'Vanguard FTSE Developed Markets ETF',
    'VUG': 'Vanguard Growth ETF',
    'IEFA': 'iShares Core MSCI EAFE ETF',
    'VTV': 'Vanguard Value ETF',
    'AGG': 'iShares Core U.S. Aggregate Bond ETF',
    'BND': 'Vanguard Total Bond Market ETF',
    'IWF': 'iShares Russell 1000 Growth ETF',
    'IJH': 'iShares Core S&P Mid-Cap ETF',
    'IEMG': 'iShares Core MSCI Emerging Markets ETF',
    'VWO': 'Vanguard FTSE Emerging Markets ETF',
    'IJR': 'iShares Core S&P Small-Cap ETF',
    'VIG': 'Vanguard Dividend Appreciation ETF',
    'VXUS': 'Vanguard Total International Stock ETF',
    'VGT': 'Vanguard Information Technology ETF',
    'VO': 'Vanguard Mid-Cap ETF'
    }

    def __init__(self, code = None, ticker = None, name = None, price = None):
        super().__init__(None, ticker)
        ETF.obj[self._code] = self
        ETF.lst.append(self._code)
    
