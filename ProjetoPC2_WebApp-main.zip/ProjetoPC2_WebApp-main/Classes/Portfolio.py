import pandas as pd
import matplotlib.pyplot as plt
from io import BytesIO
import base64

from Classes.Gclass import Gclass
from Classes.Transaction import Transaction
from Classes.Assets.Asset import Asset
from Classes.Assets.Stock import Stock
from Classes.Assets.ETF import ETF
from Classes.Assets.Cryptocurrency import Cryptocurrency
from Classes.Assets.Commodity import Commodity

class Portfolio(Gclass):
    
    obj = dict()
    lst = list()
    pos = 0
    sortkey = ''
    path = 'Data/online_broker.db'
    auto_number = 0
    nkey = 1
    att = ['_code', '_balance', '_client','_manager']
    des = ['Code', 'Balance', 'Client', 'Manager']
    header = 'Portfolio'

    def __init__(self, code = None, balance = None, client = None, manager = None):
        super().__init__()
        if code == None:
            codes = self.__class__.getatlist('_code')
            if codes == []:
                code = str(1)
            else:
                code = str(max(map(int,self.__class__.getatlist('_code'))) + 1)
        self._code = code
        self._balance = float(balance)
        self._client = str(client)
        self._manager = str(manager)
        self._transactions = []  # Lista para armazenar as transacoes
        self.preco_compra_transacoes=[]
        Portfolio.obj[code] = self
        Portfolio.lst.append(code)
    

    
    @property
    def code(self):
        return self._code
    @code.setter 
    def code(self,c):
        self._code = c
    @property
    def balance(self):
        return self._balance
    @balance.setter
    def balance(self, value):
        self._balance = float(value)
        
    def withdraw(self, quantity):
       if quantity <= self.balance:
           self.balance -= quantity
       else:
           raise ValueError('Not enough money deposited.')
           
    def deposit(self, quantity):
        self.balance += quantity
        
    @property
    def client(self):
        return self._client
    @client.setter
    def client(self, name):
        self._client = str(name)
    
    def transactions(self):
        return self._transactions
    
    def add_transaction(self, t):
        for class_name in [Stock, ETF, Commodity, Cryptocurrency]:
               if t.assets_code in class_name.available_assets:
                  asset = next((a for a in class_name.obj.values() if a.ticker == t.assets_code), None)
        #if t._assets_code in Asset.obj:
            #if  Asset.obj[t.assets_code].price * t.quantidade <= self._balance:
        if asset.price* t.quantidade <= self._balance:
                self._transactions.append(t)
                self._balance= self._balance-(asset.price *t.quantidade)
                self.preco_compra_transacoes.append(asset.price)
        else:
                raise ValueError("Insufficient balance")
        if not asset:
            raise ValueError(f"Asset {t._assets_code} not found")

        
    @property
    def manager(self):
            return self._manager
    @manager.setter
    def manager(self, value):
            self._manager = str(value)

    def estatisticas(self):
        # Criar listas para armazenar os dados
        data_transacoes = []
        quantidade_transacoes = []
        tipo_ativo_transacoes = []
        preco_ativo_transacoes = []

        for tr in self._transactions:
            for class_name in [Stock, ETF, Commodity, Cryptocurrency]:
               if tr.assets_code in class_name.available_assets:
                  asset = next((a for a in class_name.obj.values() if a.ticker == tr.assets_code), None)
            data_transacoes.append(tr.data)
            quantidade_transacoes.append(tr.quantidade)
            tipo_ativo = asset.ticker
            tipo_ativo_transacoes.append(tipo_ativo)
            preco_ativo = asset.price
            preco_ativo_transacoes.append(preco_ativo)

        # Criar o DataFrame
        df = pd.DataFrame({
            'Data': data_transacoes,
            'Quantidade': quantidade_transacoes,
            'TipoAtivo': tipo_ativo_transacoes,
            'PrecoAtivo': preco_ativo_transacoes,
            'PrecoCompra': self.preco_compra_transacoes
        })
        
        df['ValorTotal'] = df['Quantidade'] * df['PrecoCompra']
        df['ValorAtual'] = df['Quantidade'] * df['PrecoAtivo']
        
        
        df['ValorTotalG'] = 0
        for index, row in df.iterrows():
                df.at[index, 'ValorTotalG'] = sum(df.loc[:index, 'Quantidade'] * df.loc[:index, 'PrecoCompra'])

        df['ValorAtualG'] = 0
        for index, row in df.iterrows():
                df.at[index, 'ValorAtualG'] = sum(df.loc[:index, 'Quantidade'] * df.loc[:index, 'PrecoAtivo'])
                
                

        valor_total_portfolio = df['ValorTotal'].sum()
        portfolio_por_tipo_ativo = df.groupby('TipoAtivo')['ValorAtual'].sum()
        resumo_por_tipo_ativo = df.groupby('TipoAtivo').agg({'ValorTotal': 'sum', 'TipoAtivo': 'count'})


        portfolio_por_tipo_ativo.plot(kind='pie', autopct='%1.1f%%', figsize=(8, 8)) #mostrar perc na fatia
        plt.title('Distribuicao do Portfolio por Tipo de Ativo')
        plt.ylabel('')
        plt.show()
        
        valor_atual_portfolio= df['ValorAtual'].sum()
        df['RetornoPercentual'] = ((valor_atual_portfolio - valor_total_portfolio) / valor_total_portfolio) * 100
        retorno_percentual_portfolio = ((valor_atual_portfolio - valor_total_portfolio) / valor_total_portfolio) * 100

            
        df['RetornoT'] = (df['PrecoAtivo'] - df['PrecoCompra']) / df['PrecoCompra']
        desvio_padrao_retornos = df['RetornoT'].std()
        # df.plot(x='Data', y='ValorAtualG', figsize=(10, 6))  
        # plt.title('Valor do Portfolio ao Longo do Tempo')
        # plt.xlabel('Data')
        # plt.ylabel('Valor Atual do Portfolio')
        # plt.show()
        # Pie chart
        plt.figure(figsize=(8, 8))
        portfolio_por_tipo_ativo.plot(kind='pie', autopct='%1.1f%%')
        plt.title('Portfolio Distribution by Tipe of Asset')
        plt.ylabel('')
        pie_img = BytesIO()
        plt.savefig(pie_img, format='png')
        pie_img.seek(0)
        pie_url = base64.b64encode(pie_img.getvalue()).decode('utf8')
        plt.close()
        
   
        # Time series plot
        plt.figure(figsize=(10, 6))
        plt.plot(df['Data'], df['ValorAtualG'])
        plt.title('Portfolio Value Over Time')
        plt.xlabel('Data')
        plt.ylabel('Valor Atual do Portfolio')
        time_series_img = BytesIO()
        plt.savefig(time_series_img, format='png')
        time_series_img.seek(0)
        time_series_url = base64.b64encode(time_series_img.getvalue()).decode('utf8')
        plt.close()

        return df,valor_total_portfolio, valor_atual_portfolio,portfolio_por_tipo_ativo, resumo_por_tipo_ativo, retorno_percentual_portfolio, desvio_padrao_retornos,pie_url,time_series_url

