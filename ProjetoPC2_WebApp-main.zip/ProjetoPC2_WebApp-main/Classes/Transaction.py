from Classes.Gclass import Gclass
from Classes.Assets.Stock import Stock
from Classes.Assets.ETF  import ETF
from Classes.Assets.Commodity import Commodity
from Classes.Assets.Cryptocurrency import Cryptocurrency
from Classes.Assets.Asset import Asset

from datetime import datetime

class Transaction(Gclass):
    obj = dict()
    lst = list()
    pos = 0
    sortkey = ''
    auto_number = 0
    nkey = 1
    att = ['_code', '_data', '_quantidade','_Assets_code', '_port_code']
    des = ['Code', 'Data', 'Quantidade', 'Asset Code', 'Portfolio Code']
    header = 'Transacoes'

    def __init__(self, code=None, data=None, quantidade=None, assets_code=None, port_code=None):
        super().__init__()
        if code == None:
            codes = self.__class__.getatlist('_code')
            if codes == []:
                code = str(1)
            else:
                code = str(max(map(int,self.__class__.getatlist('_code'))) + 1)
        self._code = code
        self._data = datetime.now()
        self._quantidade = (quantidade)
        for class_name in [Stock, ETF, Commodity, Cryptocurrency]:
            if assets_code in class_name.available_assets:
                for asset in class_name.obj.values():
                    if asset.ticker == assets_code:
                        asset.update_price()
                        v=asset.price
        self._value = v
        self._assets_code= str(assets_code)
        self._port_code = str(port_code)
        Transaction.obj[code] = self
        Transaction.lst.append(code)

    @property 
    def code(self):
        return self._code
    @code.setter 
    def code(self,c):
        self._code = c

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def quantidade(self):
        return self._quantidade

    @quantidade.setter
    def quantidade(self, value):
        self._quantidade = float(value)

    @property
    def assets_code(self):
        return self._assets_code

    @assets_code.setter
    def assets_code(self, value):
        self._assets_code = str(value)

    @property
    def port_code(self):
        return self._port_code

    @port_code.setter
    def port_code(self, value):
        self._port_code = str(value)