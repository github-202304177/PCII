# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 22:34:26 2024

@author: anari
"""

from Classes.Gclass import Gclass
import datetime

class Notification(Gclass):
    
    received_messages = {}  # Dicionario para armazenar mensagens recebidas??
    
    obj = dict()
    lst = list()
    pos = 0
    sortkey = ''
    auto_number = 0
    nkey = 1
    att = ['_code', '_message', '_date', '_sender_code', '_receiver_code']
    des = ['Code', 'Message', 'Date', 'Sender Code', 'Receiver Code']
    header = 'Notifications'
    
    def __init__(self, code, message, sender_code, receiver_code, date=None):
        super().__init__()
        self._code = str(code)
        self._message = str(message)
        if date is None:
            self._date = datetime.date.today()
        else:
            self._date = date
        self._sender_code = str(sender_code)
        self._receiver_code = str(receiver_code)
        Notification.obj[code] = self
        Notification.lst.append(code)
    
    @property
    def receiver_code(self):
        return self._receiver_code
    
    @staticmethod
    def send_message(message, sender_code, receiver_code, date=None):
        if date is None:
            date = datetime.date.today()
        notification = Notification(Notification.auto_number + 1, message, sender_code, receiver_code, date)
        Notification.auto_number += 1
        return notification
    
    @staticmethod
    def receive_message(notification):
        Notification.received_messages[notification._code] = notification
