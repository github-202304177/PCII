"""
Created on Mon May  6 17:54:43 2024

@author: anari
"""

from Classes.Gclass import Gclass

class Manager_Portfolio(Gclass):
    obj = dict()
    lst = list()
    pos = 0
    sortkey = ''
    auto_number = 0
    nkey = 1
    att = ['_manager_code', '_port_code']
    des = ['Manager Code', 'Portfolio Code']
    header = 'Manager_Portfolio'

    def __init__(self, code,manager_code, port_code):
        super().__init__()
        
        self._code=str(code)
        self._manager_code= str(manager_code)
        self._port_code = str(port_code)
        Manager_Portfolio.obj[code] = self
        Manager_Portfolio.lst.append(code)



    @property
    def manager_code(self):
        return self._manager_code

    @manager_code.setter
    def manager_code(self, value):
        self._manager_code = str(value)

    @property
    def port_code(self):
        return self._port_code

    @port_code.setter
    def port_code(self, value):
        self._port_code = str(value)
