#  Class for al companies whose stock are being traded in the broker.
#  That does not mean that every company whose stock are tradd in the broker have an account.
#  The identifier attribute is the name of the company.

from Classes.Users.Userlogin import Userlogin
from Classes.Assets.Stock import Stock

class Company(Userlogin):

    obj = dict()
    lst = list()
    path = 'Data/online_broker.db'
    pos = 0
    sortkey = ''
    auto_number = 0
    nkey= 1
    att = ['_user', '_password', '_email']
    header = 'Companies'
    des = ['Company', 'Password', 'Email']
    
    def __init__(self, company, password, email):
        verification = False
        for ids in Stock.available_assets:
            if Stock.available_assets[ids] == company:
                verification = True
        if verification:
            super().__init__(company, 'Company', password)
            self._email = str(email)
            Company.obj[self._user] = self
            Company.lst.append(self._user)
        else:
            raise ValueError(f'The stocks of {company} are not traded on this broker.')

    @property
    def email(self):
        return self._email
    @email.setter
    def email(self, email):
        self._email = email
