from Classes.Users.Userlogin import Userlogin

class Manager(Userlogin):
    
    obj = dict()
    lst = list()
    path = 'Data/online_broker.db'
    pos = 0
    sortkey = ''
    auto_number = 0
    nkey= 1
    att = ['_user', '_password','_phone','_email']
    header = 'Clients'
    des = ['Name', 'Password','Phone','Email']
    
    def __init__(self, name, password, phone, email):
        super().__init__(name, 'Manager', password)
        self._phone = int(phone)
        self._email = str(email)
        Manager.obj[self._user] = self
        Manager.lst.append(self._user)
        
    @property
    def phone(self):
        return self._phone

    @phone.setter
    def phone(self, value):
        self._phone = int(value)

    @property
    def email(self):
        return self._email

    @email.setter
    def email(self, value):
        self._email = str(value)