# This is the class that allows management of the subclasses Client, Company and Manager.
# They are only different usergroups and the functions of each can be read on the README.mf file.

import bcrypt
from Classes.Gclass import Gclass

class Userlogin(Gclass):
    
    obj = dict()
    lst = list()
    pos = 0
    sortkey = ''
    auto_number = 0
    nkey = 1
    path = 'Data/online_broker.db'
    att = ['_user','_usergroup','_password']
    header = 'Users'
    des = ['User','User group','Password']
    username = ''
    if str(type(username)) == 'Userlogin':
        grupo = eval('Userlogin.obj[Userlogin.username].usergroup')
          
    def __init__(self, user, usergroup, password):
        super().__init__()
        # Nome do utilizador único
        self._user = user
        # Nome do grupo.
        self._usergroup = usergroup
        # Password do utilizador - encriptada e armazenada na Base de Dados.
        # Na validação é encriptada a password fornecida e comparada com a da Base de Dados. Não é possível obter a password do utilizador por consulta da Base de Dados.
        self._password = password
        Userlogin.obj[user] = self
        Userlogin.lst.append(user)

    @property
    def user(self):
        return self._user
    
    @property
    def usergroup(self):
        return self._usergroup
    
    @usergroup.setter
    def usergroup(self, ug):
        self._usergroup = ug
        
    @property
    def password(self):
        return ''
    
    @password.setter
    def password(self, pw):
        self._password = pw

     # 'chk_password' - validação da password de um utilizador.'Valid' se coincidir com a password, 'Wrong password' utilizador existe mas password não coincide,'No existent user'.
     # Combinação válida - utilizador armazenado em Userlogin.username.Saber em cada momento se há algum utilizador validado e quem é esse utilizador.
    @staticmethod
    def chk_password(user, password):
        Userlogin.username = ''
        if user in Userlogin.obj:
            obj = Userlogin.obj[user]
            valid = bcrypt.checkpw(password.encode(), obj._password.encode())
            if valid:
                Userlogin.username = user
                message = "Valid"
            else:
                message = 'Wrong password'
        else:
            message = 'No existent user'
        return message
   
    #'set_password' - permite encriptar a password do utilizador.
    @staticmethod
    def set_password(password):
        return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    
    
    
    
    
    
    
    
    
    
    
    
    