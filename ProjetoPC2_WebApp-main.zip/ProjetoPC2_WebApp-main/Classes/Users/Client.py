import datetime

from Classes.Users.Userlogin import Userlogin
from Classes.Portfolio import Portfolio
from Classes.Notification import Notification

class Client(Userlogin):
    
    obj = dict()
    lst = list()
    path = 'Data/online_broker.db'
    pos = 0
    sortkey = ''
    auto_number = 0
    nkey= 1
    att = ['_user', '_password','_phone','_email']
    header = 'Clients'
    des = ['Name', 'Password','Phone','Email']
    
    def __init__(self, name, password, phone, email, birthday = '1920-1-1', port_code = None, notifications = None):
        if birthday == None or (datetime.datetime.now().replace(second=0, microsecond=0) - datetime.datetime.strptime(birthday, '%Y-%m-%d')).days // 365 >= 18:
            super().__init__(name, 'Client', password)
            self._birthday = datetime.datetime.strptime(birthday, '%Y-%m-%d')
            self._phone = int(phone)
            self._email = str(email)
            port = Portfolio(None, 0, name)
            self._portfolio_code = port.code
            self._notifications = list()
            Client.obj[self._user] = self
            Client.lst.append(self._user)
        else:
            raise ValueError('You need to be 18 years old to create an account.')
          
    @property
    def birthday(self):
        return self._birthday.strftime("%d/%m/%y")

    @property
    def phone(self):
        return self._phone

    @phone.setter
    def phone(self, value):
        self._phone = int(value)

    @property
    def email(self):
        return self._email

    @email.setter
    def email(self, value):
        self._email = str(value)
        
    @property
    def portfolio_code(self):
        return self._portfolio_code
    
    def update_notifications(self):
        for el in Notification.obj:
            if el.receiver_code == self.user:
                self._notifications.append(Notification.obj[el])