# Importar as bibliotecas necessárias
import sys # Permite a saída do programa em caso de erro.
import datetime # Identificação do atributo do tipo ‘Date’.
import sqlite3 # Armazena os objetos na Base de Dados.

class Gclass:
       
    # A criação dos atributos é feita nas classes derivadas.
    def __init__(self):
        pass
    
    # Criar um objeto com base numa string com os seus atributos separados por ';'. Utilizado nos ficheiros .csv.
    @classmethod
    def from_string(cls, str_data):
        str_lst = str_data.split(';')
        str_arg = 'cls(str_lst[0]'
        for i in range(1, len(str_lst)):
            str_arg += ',str_lst[' + str(i) + ']'
        str_arg += ')'
        return eval(str_arg)
    
    # A classe fica sem registos.
    @classmethod 
    def reset(cls):
        cls.obj = dict()
        cls.lst = list()
        cls.pos = 0
           
    # Para associações de muitos para muitos com junção dos atributos identificadores
    # Retorna uma sub-lista dos atributos identificadores 'lst' que contêm o valor 'firstkey'.
    @classmethod 
    def getlines(cls, firstkey):
        return list(filter(lambda x: x.startswith(firstkey), cls.lst))
    
    # Próximo objeto. Retorna 'None' se for o último.
    @classmethod
    def nextrec(cls):
        cls.pos += 1
        return cls.current()
    
    # Objeto anterior. Retorna 'None' se for o primeiro.
    @classmethod
    def previous(cls):
        cls.pos-= 1
        return cls.current()
    
    # Retorna o objeto corrente. Define o objeto com o id 'code' como o objeto corrente.
    @classmethod
    def current(cls, code = None):
        if code in cls.lst:
            cls.pos = cls.lst.index(code)
        if cls.pos < 0:
            cls.pos = 0
            return None
        elif cls.pos >= len(cls.lst):
            cls.pos  = len(cls.lst) - 1
            return None
        else:
            code = cls.lst[cls.pos]
            return cls.obj[code]
        
    # Vai para o início. Retorna o primeiro objeto.
    @classmethod
    def first(cls):
        cls.pos = 0
        return cls.current()
    
    # Vai para o fim. Retorna o último objeto.
    @classmethod
    def last(cls):
        cls.pos = len(cls.lst) - 1
        return cls.current()
    
    # Remove o objeto com id 'p' da lista ‘lst’ e da Base de Dados.
    @classmethod
    def remove(cls, p):
        obj = cls.obj[p]
        if cls.nkey == 1:
            code = cls.att[0][1:]
            command = f'DELETE FROM {cls.__name__} WHERE {code}={cls.conv(obj,code,p)}'
        elif cls.nkey == 2:
            code1 = cls.att[0][1:]
            code2 = cls.att[1][1:]
            value1 = getattr(obj, code1)
            value2 = getattr(obj, code2)
            command = f'DELETE FROM {cls.__name__} WHERE {code1}={cls.conv(obj, code1, value1)}'
            command = command + f' AND {code2}={cls.conv(obj, code2, value2)}'
        cls.sqlexe(command)
        cls.lst.remove(p)
        del cls.obj[p]
        
    # Insere o objeto com id 'p' na Base de Dados.
    @classmethod
    def insert(cls, p):
        obj = cls.obj[p]
        command = f'INSERT INTO {cls.__name__} VALUES('
        for att in cls.att:
            value = getattr(obj, att)
            command += f'{cls.conv(obj, att, value)},'
        command = command[:-1] + ")"
        cls.sqlexe(command)
    
    # Atualiza o objeto com id 'p' na Base de Dados.
    @classmethod
    def update(cls, p):
        obj = cls.obj[p]
        command = f'UPDATE "{cls.__name__}" SET'
        for att in cls.att:
            value = getattr(obj, att)
            command += f' {att[1:]} = {cls.conv(obj, att, value)},'
        if cls.nkey == 1:
            code = cls.att[0][1:]
            command = command[:-1] + f' WHERE {code} = {cls.conv(obj, code, p)}'
        elif cls.nkey == 2:
            code1 = cls.att[0][1:]
            code2 = cls.att[1][1:]
            value1 = getattr(obj, code1)
            value2 = getattr(obj, code2)
            command = command[:-1] + f' WHERE {code1} = {cls.conv(obj, code1, value1)}'
            command = command + f' AND {code2}={cls.conv(obj, code2, value2)}'
        cls.sqlexe(command)
        
    # Se o valor do atributo att é str ou datetime retorna com aspas.
    @staticmethod
    def conv(obj, att, value):
        v = getattr(obj, att)
        if type(v) == str or type(v) == datetime.date:
            ret = f'"{value}"'
        else:
            ret = f'{value}'
        return ret
    

    @classmethod
    def orderfunc(cls, e):
        return getattr(cls.obj[e], cls.sortkey)
    
    # Ordena 'lst' por ordem crescente/decrescente do atributo 'att' passado como argumento.
    # 'reverse' - 'False' é crescente, 'True' é decrescente.  
    @classmethod
    def sort(cls, att, reverse = False):
        cls.sortkey = att
        cls.lst.sort(key=cls.orderfunc, reverse= reverse)
        
    # Retorna uma lista com 'obj' cujo 'value' igual ao valor do atributo 'att'.
    @classmethod
    def find(cls, value, att):
        lobj = cls.obj.values()
        fobj = [obj for obj in lobj if getattr(obj, att) == value]
        return fobj
    
    # Redefine 'lst' com os ids cujos atributos pertençam às listas de 'f_dic'.
    # Reset do filtro -  chamar o método 'set_filter()' sem parâmetros.
    # exemplo: f_dic = {'name':['carlos','barbara'], 'salary':[5000,6000]} 
    @classmethod
    def set_filter(cls, f_dic = {}):
        if f_dic:
            code = cls.att[0]
            lobj = cls.obj.values()
            s = set()
            for att,listf in f_dic.items():
                s1 = set([getattr(obj, code) for obj in lobj if getattr(obj, att) in listf])
                s = s.union(s1)
            if len(s) > 0:
                cls.lst = list(s)
                cls.pos = 0
        else:
            obj = cls.current()
            cls.lst = list(cls.obj.keys())
            code = cls.att[0]
            cls.current(getattr(obj, code))
            
    # Retorna uma lista com os valores de 'att' dos objetos da classe.
    @classmethod
    def getatlist(cls, att):
        return [getattr(obj, att) for obj in list(cls.obj.values())]
    
    # Lê atributos e cria os objetos a partir da Base de Dados. Tem que existir uma tabela com o nome da classe.
    @classmethod
    def read(cls, path = ''):
        cls.obj = dict()
        cls.lst = list()
        cls.path = path
        try:
            fh = open(path, 'r')
            fh.close()
            lista = cls.sqlexe("select * from " + cls.__name__)
            if lista != None:
                for r in lista:
                    objstr = f'{r[0]}'
                    for att in range(1,len(lista[0])):
                        objstr += f';{r[att]}'
                    cls.from_string(objstr)
        except FileNotFoundError:
            print(f"ERROR: {path} data file not found")
        except BaseException as err:
            print(f"Error in read method:\n{err}\n{type(err)}")
            sys.exit()
            
    # Retorna a informação do objeto no formato (atrib1;atrib2;…). 
    def __str__(self):
        strprint = "f'"
        for att in type(self).att:
            strprint += '{self.' + att + '};'
        strprint = strprint[:-1] + "'"
        return eval(strprint)
    
    #  Método para executar comandos SQL na Base de Dados.
    @classmethod
    def sqlexe(cls, command):
        resul = None
        try:
            con = sqlite3.connect(cls.path)
            cur = con.cursor()
            con.row_factory = sqlite3.Row
            tname = cls.__name__
            cur = con.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{tname}'")
            table = cur.fetchone()
            if table is None or table[0] != tname:
                print(f"ERROR: table {tname} missing in database {cls.path}")
                sys.exit()
            cur = con.execute(command)
            resul = cur.fetchall()
            con.commit()
            con.close()
        except sqlite3.Error as er:
            print(f'sqlite error: {er}')
        return resul