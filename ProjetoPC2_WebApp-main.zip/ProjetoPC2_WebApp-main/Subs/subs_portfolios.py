from flask import render_template

from Classes.Portfolio import Portfolio

current_index = 0

def all_portfolios(action='',ulogin=''):
    global current_index
    if action == 'next':
        current_index += 1
        if current_index + 1 > len(Portfolio.obj):
            current_index = 0
    elif action == 'previous':
        current_index -= 1
        if current_index < 0:
            current_index = len(Portfolio.obj) - 1
    portfolio = Portfolio.obj[Portfolio.lst[current_index]]
    df, valor_total_portfolio, valor_atual_portfolio, portfolio_por_tipo_ativo, resumo_por_tipo_ativo, retorno_percentual_portfolio, desvio_padrao_retornos,pie_url,time_series_url = Portfolio.estatisticas(portfolio)
    return render_template('clients_portfolios.html',ulogin = ulogin, portfolio=portfolio, group = "Manager", vtf = valor_total_portfolio, vaf = valor_atual_portfolio, rpp = retorno_percentual_portfolio, dpr = desvio_padrao_retornos)