from flask import render_template, session
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import base64
import io

from Classes.Assets.Stock import Stock
from Classes.Assets.ETF import ETF
from Classes.Assets.Cryptocurrency import Cryptocurrency
from Classes.Assets.Commodity import Commodity
from Classes.Users.Userlogin import Userlogin
from Classes.Users.Client import Client


def asset_tables(cname=''):
    ulogin=session.get("user")
    group = None
    company_name = None
    if ulogin != None:
        group = Userlogin.obj[ulogin].usergroup
        if group == "Company":
            company_name = Userlogin.obj[ulogin].user
        if group == "Client":
            phone = Client.obj[ulogin].phone
    if (ulogin != None):
        print(cname)
        sbl = eval(cname)
        headers = list()        
        for i in range(1, len(sbl.att)): 
                headers.append(sbl.att[i][1:])        
        objl = list()
        for line in sbl.lst:
            objl.append(sbl.obj[line])
        return render_template("asset_tables.html", cname=cname, ulogin=session.get("user"), phone=phone,
                    objl=objl,header=sbl.header, desl=sbl.des[1:], attl=sbl.att[1:], group=group, company_name=company_name)
    else:
        return render_template("index.html", ulogin=ulogin)



def update_all_prices(cname=''):
    for el in cname.obj:
        cname.obj[el].update_price()
        
def create_figure(ticker, c_name, n_days=10):
    data = eval(c_name).last_n_days_prices(ticker, n_days)
    fig, ax = plt.subplots()
    ax.plot(data.index, data['close'], label=ticker.upper(), color='black', linestyle='-', marker='o')
    ax.set_xlabel('Date', fontsize=14)
    ax.set_ylabel('US$', fontsize=14)
    ax.set_title(f'Last {n_days} Days Close Prices for {ticker.upper()}', fontsize=16)
    ax.legend(loc='upper left', fontsize=12)
    ax.grid(True, linestyle='--', linewidth=0.5)
    locator = mdates.DayLocator(interval=max(1, n_days // 4))
    formatter = mdates.ConciseDateFormatter(locator)
    ax.xaxis.set_major_locator(locator)
    ax.xaxis.set_major_formatter(formatter)
    plt.xticks(rotation=45)
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%d-%m'))
    ax.tick_params(axis='both', which='major', labelsize=12)
    return fig
     
def asset_page(ticker='',cname=''):
    sbl = eval(cname)
    for el in sbl.obj:
        if sbl.obj[el].ticker == ticker:
            asset = sbl.obj[el]
    ticker = asset.ticker
    name = asset.name
    price = asset.price
    fig = create_figure(ticker, cname, 10)
    output = io.BytesIO()
    FigureCanvas(fig).print_png(output)
    plot_img = base64.b64encode(output.getvalue()).decode('utf-8')
    return render_template('asset_page.html',name=name,cname=cname,ticker=ticker,price=price,n_days=10,plot_img=plot_img)

def plot_prices(c_name='', n_days=10, ticker='', price=None):
    sbl = eval(c_name)
    for el in sbl.obj:
        if sbl.obj[el].ticker == ticker:
            asset = sbl.obj[el]
    fig = create_figure(ticker, c_name, n_days)
    output = io.BytesIO()
    FigureCanvas(fig).print_png(output)
    plot_img = base64.b64encode(output.getvalue()).decode('utf-8')
    return render_template('asset_page.html',name=asset.name,cname=c_name,ticker=ticker,price=price,n_days=n_days,plot_img=plot_img)