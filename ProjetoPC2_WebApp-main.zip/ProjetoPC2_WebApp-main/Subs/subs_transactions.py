from flask import render_template, session, request

from Classes.Users.Client import Client
from Classes.Users.Userlogin import Userlogin
from Classes.Transaction import Transaction

def transactions(phone=''):
    global prev_option
    for cli in Client.obj:
        if Client.obj[cli].phone == eval(phone):
            client = Client.obj[cli].user
    return render_template('transactions.html', client=client, ulogin=client, group='Client')

def open_positions(phone=''):
    global prev_option
    for cli in Client.obj:
        if Client.obj[cli].phone == eval(phone):
            client = Client.obj[cli].user
    return render_template('open_positions.html', client=client, group='Client')