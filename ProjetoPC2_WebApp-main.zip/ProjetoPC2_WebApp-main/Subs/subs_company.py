from flask import render_template
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import base64
import io

from Classes.Assets.Stock import Stock

def create_figure(ticker, n_days=10):
    data = Stock.last_n_days_prices(ticker, n_days)
    fig, ax = plt.subplots()
    ax.plot(data.index, data['close'], label=ticker.upper(), color='black', linestyle='-', marker='o')
    ax.set_xlabel('Date', fontsize=14)
    ax.set_ylabel('US$', fontsize=14)
    ax.set_title(f'Last {n_days} Days Close Prices for {ticker.upper()}', fontsize=16)
    ax.legend(loc='upper left', fontsize=12)
    ax.grid(True, linestyle='--', linewidth=0.5)
    locator = mdates.DayLocator(interval=max(1, n_days // 4))
    formatter = mdates.ConciseDateFormatter(locator)
    ax.xaxis.set_major_locator(locator)
    ax.xaxis.set_major_formatter(formatter)
    plt.xticks(rotation=45)
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%d-%m'))
    ax.tick_params(axis='both', which='major', labelsize=12)
    return fig

def page(company_name='',ulogin='', group=''):
    for el in Stock.available_assets:
        if Stock.available_assets[el] == company_name:
            ticker = el
    if ticker not in Stock.obj:
        asset = Stock(None, ticker)
    if ticker in Stock.obj:
        asset = Stock.obj[ticker]
    name = asset.name
    price = asset.price
    fig = create_figure(ticker, 10)
    output = io.BytesIO()
    FigureCanvas(fig).print_png(output)
    plot_img = base64.b64encode(output.getvalue()).decode('utf-8')
    major, institutional = asset.get_holders()
    stats = asset.get_stats_valuation()
    return render_template('company_page.html',name=name,ticker=ticker,price=price,n_days=10,plot_img=plot_img,major=major,institutional=institutional,stats=stats,ulogin=ulogin, group=group, company_name=company_name)

def plot_prices(n_days=10, ticker='', price=None, name='',major='',institutional='',stats='',ulogin='', group='', company_name=''):
    fig = create_figure(ticker, n_days)
    output = io.BytesIO()
    FigureCanvas(fig).print_png(output)
    plot_img = base64.b64encode(output.getvalue()).decode('utf-8')
    return render_template(
        'company_page.html',
        name=name,
        ticker=ticker,
        price=price,
        n_days=n_days,
        plot_img=plot_img,major=major,institutional=institutional,stats=stats,
        ulogin=ulogin, group=group, company_name=company_name,
    )