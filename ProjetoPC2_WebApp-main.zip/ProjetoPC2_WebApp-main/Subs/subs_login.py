from flask import render_template, request, session

from Classes.Users.Userlogin import Userlogin
from Classes.Users.Client import Client

def login():
    return render_template("login.html", user= "", password="", ulogin=session.get("user"),resul = "")

def logoff():
    session.pop("user",None)
    return render_template("index.html", ulogin=session.get("user"))

def chklogin():
    user = request.form["user"]
    password = request.form["password"]
    resul = Userlogin.chk_password(user, password)
    if resul == "Valid":
        session["user"] = user
        ulogin=session.get("user")
        group = None
        company_name = None
        phone = None
        email = None
        birthday = None
        if ulogin != None:
            group = Userlogin.obj[ulogin].usergroup
            if group == "Company":
                company_name = Userlogin.obj[ulogin].user
            if group == "Client":
                phone = Client.obj[ulogin].phone
                email = Client.obj[ulogin].email
                birthday = Client.obj[ulogin].birthday
        return render_template("index.html", ulogin=ulogin, phone=phone, email=email, birthday=birthday, group=group, company_name=company_name)
    return render_template("login.html", user=user, password = password, ulogin=session.get("user"),resul = resul)