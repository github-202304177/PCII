# Stocks - perfeitamente funcional
from Classes.Assets.Stock import Stock
for el in Stock.available_assets:
    st = Stock(None, el)
    print(st)
    print(st.pricerecord)
    
# ETFs - perfeitamente funcional
from Classes.Assets.ETF import ETF
for el in ETF.available_assets:
    st = ETF(None, el)
    print(st)
    print(st.pricerecord)

# Commodities - perfeitamente funcional
from Classes.Assets.Commodity import Commodity
for el in Commodity.available_assets:
    cmd = Commodity(None, el)
    print(cmd)
    print(cmd.pricerecord)

# Cryptocurrencies - perfeitamente funcional
from Classes.Assets.Cryptocurrency import Cryptocurrency
for el in Cryptocurrency.available_assets:
    st = Cryptocurrency(None, el)
    print(st)
    print(st.pricerecord)