# Depois de correr testes, convém ir apagar a base de dados e iniciar
# todos os objetos através de Tests/create_assets_and_users.py
# Mover para a root para funcionar

from Classes.Assets.Stock import Stock
from Classes.Assets.ETF import ETF
from Classes.Assets.Commodity import Commodity
from Classes.Assets.Cryptocurrency import Cryptocurrency

path = "Data/online_broker.db"

cname = "Cryptocurrency" # só trocar a string pelo nome das outras classes e os tickers em baixo

cl = eval(cname)
cl.read(path)

obj = cl.from_string("None;BTC")
print("objeto sem estar gravado ",obj)
cl.insert(getattr(obj,cl.att[0]))

obj = cl.from_string("None;ETH")
cl.insert(getattr(obj,cl.att[0]))

print("\nLista dos objetos gravados " ,cl.lst)

obj = cl.first()
print ("\nPrimeiro objeto gravado ",obj)
obj.ticker = "BNB"
cl.update(getattr(obj, cl.att[0]))

cl.read(path)

print("\nobjectos gravados")    
for code in cl.lst:
    print(cl.obj[code])
