# -*- coding: utf-8 -*-
"""
Created on Mon May 13 19:08:15 2024

@author: anari
"""

import datetime
import pandas as pd
import matplotlib.pyplot as plt

def estatisticas():
    # Criar listas para armazenar os dados
    data_transacoes = []
    quantidade_transacoes = [1,2,6]
    tipo_ativo_transacoes = ["ETF", "Stock", "crypto"]
    preco_ativo_transacoes = [3000,1000,2000]
    preco_compra_transacoes=[2,999,4]

    d1=datetime.datetime.strptime("12-02-2022", "%d-%m-%Y")
    d2=datetime.datetime.strptime("13-02-2022", "%d-%m-%Y")
    d3=datetime.datetime.strptime("14-02-2022", "%d-%m-%Y")
    data_transacoes.append(d1)
    data_transacoes.append(d2)
    data_transacoes.append(d3)


    # Criar o DataFrame
    df = pd.DataFrame({
        'Data': data_transacoes,
        'Quantidade': quantidade_transacoes,
        'TipoAtivo': tipo_ativo_transacoes,
        'PrecoAtivo': preco_ativo_transacoes,
        'PrecoCompra': preco_compra_transacoes
    })
    
    df['ValorTotal'] = df['Quantidade'] * df['PrecoCompra']
    df['ValorAtual'] = df['Quantidade'] * df['PrecoAtivo']
    
    
    df['ValorTotalG'] = 0
    for index, row in df.iterrows():
            df.at[index, 'ValorTotalG'] = sum(df.loc[:index, 'Quantidade'] * df.loc[:index, 'PrecoCompra'])

    df['ValorAtualG'] = 0
    for index, row in df.iterrows():
            df.at[index, 'ValorAtualG'] = sum(df.loc[:index, 'Quantidade'] * df.loc[:index, 'PrecoAtivo'])
            
            

    valor_total_portfolio = df['ValorTotal'].sum()
    portfolio_por_tipo_ativo = df.groupby('TipoAtivo')['ValorAtual'].sum()
    resumo_por_tipo_ativo = df.groupby('TipoAtivo').agg({'ValorTotal': 'sum', 'TipoAtivo': 'count'})


    portfolio_por_tipo_ativo.plot(kind='pie', autopct='%1.1f%%', figsize=(8, 8)) #mostrar perc na fatia
    plt.title('Distribuicao do Portfolio por Tipo de Ativo')
    plt.ylabel('')
    plt.show()
    
    valor_atual_portfolio= df['ValorAtual'].sum()
    df['RetornoPercentual'] = ((valor_atual_portfolio - df['PrecoCompra']) / df['PrecoCompra']) * 100
    retorno_percentual_portfolio = ((valor_atual_portfolio - df['PrecoCompra'].sum()) / df['PrecoCompra'].sum()) * 100

        
    df['RetornoT'] = (df['PrecoAtivo'] - df['PrecoCompra']) / df['PrecoCompra']
    desvio_padrao_retornos = df['RetornoT'].std()
    df.plot(x='Data', y='ValorAtualG', figsize=(10, 6))  
    plt.title('Valor do Portfolio ao Longo do Tempo')
    plt.xlabel('Data')
    plt.ylabel('Valor Atual do Portfolio')
    plt.show()

    return df,valor_total_portfolio, valor_atual_portfolio,portfolio_por_tipo_ativo, resumo_por_tipo_ativo, retorno_percentual_portfolio, desvio_padrao_retornos

print(estatisticas())