# Depois de correr testes, convém ir apagar a base de dados e iniciar
# todos os objetos através de Tests/create_assets_and_users.py
# Mover para a root para funcionar


from Classes.Users.Company import Company as c
from Classes.Users.Client import Client as cl
from Classes.Users.Manager import Manager as m
from Classes.Users.Userlogin import Userlogin
from Classes.Assets.Stock import Stock

path = "Data/online_broker.db"


c.read(path)
cl.read(path)
m.read(path)


obj_c = c.from_string("Chevron Company;7890;ccom@gmail.com")
print("objeto sem estar gravado Company",obj_c)
obj_cl = cl.from_string("Joao Carlos;asdf;3000;987987987;joao@gmail.com")
print("objeto sem estar gravado Client",obj_cl)
obj_m = m.from_string("Jose Marques;asdf;987987987;marques@gmail.com")
print("objeto sem estar gravado Manager",obj_m)


c.insert(getattr(obj_c,c.att[0]))
cl.insert(getattr(obj_cl,cl.att[0]))
m.insert(getattr(obj_m,m.att[0]))


Userlogin.insert(getattr(obj_c,c.att[0]))
Userlogin.insert(getattr(obj_cl,cl.att[0]))
Userlogin.insert(getattr(obj_m,m.att[0]))


obj_c = c.from_string("Visa Inc;1237;visa@gmail.com")
obj_cl = cl.from_string("Carlos Marques;89jk;5000;967487127;carlos@gmail.com")
obj_m = m.from_string("Jose Silva;89jk;967487127;silva@gmail.com")


c.insert(getattr(obj_c,c.att[0]))
cl.insert(getattr(obj_cl,cl.att[0]))
m.insert(getattr(obj_m,m.att[0]))


Userlogin.insert(getattr(obj_c,c.att[0]))
Userlogin.insert(getattr(obj_cl,cl.att[0]))
Userlogin.insert(getattr(obj_m,m.att[0]))


print("\nLista dos objetos gravados Company" ,c.lst)
print("\nLista dos objetos gravados Client" ,cl.lst)
print("\nLista dos objetos gravados Manager" ,m.lst)


print("\nLista dos objetos gravados Userlogin", Userlogin.lst)


obj_c = c.first()
obj_cl = cl.first()
obj_m = m.first()


print ("\nPrimeiro objeto gravado Company ",obj_c)
print ("\nPrimeiro objeto gravado Client",obj_cl)
print ("\nPrimeiro objeto gravado Managaer",obj_m)


obj_c.password = "9876"
obj_cl.password = "hjkl"
obj_m.password = "hj67"


c.update(getattr(obj_c, c.att[0]))
cl.update(getattr(obj_cl, cl.att[0]))
m.update(getattr(obj_m, m.att[0]))


Userlogin.update(getattr(obj_c, c.att[0]))
Userlogin.update(getattr(obj_cl, cl.att[0]))
Userlogin.update(getattr(obj_m, m.att[0]))


c.read(path)
cl.read(path)
m.read(path)


Userlogin.read(path)


print("\nobjectos gravados Company")    
for code in c.lst:
    print(c.obj[code])
print("\nobjectos gravados Client")    
for code in cl.lst:
    print(cl.obj[code])
print("\nobjectos gravados Manager")    
for code in m.lst:
    print(m.obj[code])
print("\nobjectos gravados Userlogin") 
for code in Userlogin.lst:
    print(Userlogin.obj[code])
    


