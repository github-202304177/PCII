# This file creates objects for all assets traded in the broker and inserts them in the data base.
# Besides, it also creates users with the data you can see below.
# In order to work normally, it needs to be located in the root of the project.

import bcrypt

from Classes.Assets.Stock import Stock
from Classes.Assets.ETF  import ETF
from Classes.Assets.Commodity import Commodity
from Classes.Assets.Cryptocurrency import Cryptocurrency
from Classes.Assets.Asset import Asset

for class_name in ['Stock', 'ETF', 'Commodity', 'Cryptocurrency']:
    print('\n ====== ' + class_name + ' ====== \n')
    class_name = eval(class_name)
    class_name.reset()
    class_name.path = 'Data/online_broker.db'
    for el in class_name.available_assets:
        obj = class_name(None, el)
        class_name.insert(getattr(obj, class_name.att[0]))
    print("\nObjectos gravados:\n")    
    for code in class_name.lst:
        print(class_name.obj[code])
        
print('\n ====== All Assets ====== ')
print("\nObjectos gravados:\n")    
for code in Asset.lst:
    print(Asset.obj[code])
    
from Classes.Users.Client import Client
from Classes.Users.Company import Company
from Classes.Users.Manager import Manager
from Classes.Users.Userlogin import Userlogin

Client.reset()
Company.reset()
Manager.reset()
Userlogin.reset()

def set_password(password):
    passencrypted = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
    return passencrypted.decode()

obj = Manager('Carlos Moedas', set_password('ministerio'), 987654321, 'cmlisboa@cmlisboa.com')
Manager.insert(getattr(obj, Manager.att[0]))
Userlogin.insert(getattr(obj, Userlogin.att[0]))

obj = Client('Tiago Praca', set_password('webapp'), 987876765, 'tiago@hotmail.com', '2000-12-9', port_code = None, notifications = None)
Client.insert(getattr(obj, Client.att[0]))
Userlogin.insert(getattr(obj, Userlogin.att[0]))

obj = Client('Cesar Augusto', set_password('roma'), 912365487, 'imperador@gmail.com', '1990-10-11', port_code = None, notifications = None)
Client.insert(getattr(obj, Client.att[0]))
Userlogin.insert(getattr(obj, Userlogin.att[0]))

obj = Client('Pr. Carlos Braganca', set_password('programacao'), 937987234, 'professor@up.pt', '1988-9-2', port_code = None, notifications = None)
Client.insert(getattr(obj, Client.att[0]))
Userlogin.insert(getattr(obj, Userlogin.att[0]))

obj = Company('Apple Inc', set_password('iphone'), 'apple@apple.com')
Company.insert(getattr(obj, Company.att[0]))
Userlogin.insert(getattr(obj, Userlogin.att[0]))

obj = Company('Microsoft Corp', set_password('billgates'), 'msft@microsoft.com')
Company.insert(getattr(obj, Company.att[0]))
Userlogin.insert(getattr(obj, Userlogin.att[0]))

print('\n ====== All Users ====== ')
print("\nObjectos gravados:\n")    
for code in Userlogin.lst:
    print(Userlogin.obj[code])
    
