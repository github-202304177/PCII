
from flask import Flask, render_template, request, session, redirect, url_for
import pandas as pd
import datetime

from Classes.Assets.Stock import Stock
from Classes.Assets.ETF import ETF
from Classes.Assets.Cryptocurrency import Cryptocurrency
from Classes.Assets.Commodity import Commodity
from Classes.Users.Userlogin import Userlogin
from Classes.Users.Client import Client
from Classes.Users.Manager import Manager
from Classes.Users.Company import Company
from Classes.Notification import Notification
from Classes.Portfolio import Portfolio
from Classes.Transaction import Transaction

from datafile import filename

app = Flask(__name__)

Stock.read(filename + 'online_broker.db')
ETF.read(filename + 'online_broker.db')
Cryptocurrency.read(filename + 'online_broker.db')
#Commodity.read(filename + 'online_broker.db') (ocasionalmente da erro, optamos por retirar)
Client.read(filename + 'online_broker.db')
Manager.read(filename + 'online_broker.db')
Company.read(filename + 'online_broker.db')
Portfolio.read(filename + 'online_broker.db')

import Subs.subs_login as lsub
import Subs.subs_asset_search as assub
import Subs.subs_company as csub
import Subs.subs_transactions as tsub
import Subs.subs_portfolios as psub

app.secret_key = 'BAD_SECRET_KEY'

@app.route("/")
def index():
    ulogin=session.get("user")
    group = None
    company_name = None
    phone=None
    email=None
    birthday=None
    if ulogin != None:
        group = Userlogin.obj[ulogin].usergroup
        if group == "Company":
            company_name = Userlogin.obj[ulogin].user
        if group == "Client":
            phone = Client.obj[ulogin].phone
            email = Client.obj[ulogin].email
            birthday = Client.obj[ulogin].birthday
    return render_template("index.html", ulogin=session.get("user"),phone=phone, email=email, birthday=birthday, group = group, company_name = company_name)

@app.route("/login")
def login():
    return lsub.login()

@app.route("/logoff")
def logoff():
    return lsub.logoff()

@app.route("/chklogin", methods=["post","get"])
def chklogin():
    return lsub.chklogin()

@app.route('/plot.html', methods=['GET'])
def plot_html():
    c_name = request.args.get("c_name")
    n_days = int(request.args.get("n_days"))
    ticker = request.args.get("ticker")   
    price = request.args.get("price") 
    return assub.plot_prices(c_name, n_days, ticker, price)

@app.route("/asset_tables/<cname>", methods=["post","get"])
def asset_tables(cname=''):
    return assub.asset_tables(cname)
        
@app.route("/refresh_price", methods=["POST"])
def refresh_price():
    cname = request.form.get("cname")
    assub.update_all_prices(eval(cname))
    return redirect(url_for('asset_tables', cname=cname))

@app.route("/asset_page/<cname>/<ticker>", methods=["post","get"])
def asset_page(ticker='', cname=''):
    return assub.asset_page(ticker, cname)

@app.route("/company_page/<company_name>", methods=["post","get"])
def company_page(company_name=''):
    ulogin=session.get("user")
    group = None
    if ulogin != None:
        group = Userlogin.obj[ulogin].usergroup
    return csub.page(company_name=company_name, ulogin=ulogin, group=group)

@app.route('/plot_c.html', methods=['GET'])
def plot_c_html():
    n_days = int(request.args.get("n_days"))
    ticker = request.args.get("ticker")   
    price = request.args.get("price")
    name = request.args.get("name")
    company_name=request.args.get("company_name")
    ulogin=session.get("user")
    major = pd.read_json(request.args.get("major"))
    institutional = pd.read_json(request.args.get("institutional"))
    stats = pd.read_json(request.args.get("stats"))
    group = None
    if ulogin != None:
        group = Userlogin.obj[ulogin].usergroup
    return csub.plot_prices(n_days, ticker, price, name, major=major,institutional=institutional,stats=stats, ulogin=ulogin, group=group, company_name=company_name)


@app.route("/open_positions/<phone>", methods=["post","get"])
def open_positions(phone=''):
    return tsub.open_positions(phone)

@app.route("/clients_portfolios", methods=["post", "get"])
def clients_portfolios():
    ulogin=session.get("user")
    for p in Portfolio.obj:
                if Portfolio.obj[p].manager == ulogin:
                    portfolio=Portfolio.obj[p]
    df, valor_total_portfolio, valor_atual_portfolio, portfolio_por_tipo_ativo, resumo_por_tipo_ativo, retorno_percentual_portfolio, desvio_padrao_retornos,pie_url,time_series_url = Portfolio.estatisticas(portfolio)
    return render_template('clients_portfolios.html', ulogin=ulogin, portfolio = Portfolio.obj[Portfolio.lst[0]], group = 'Manager', vtf = valor_total_portfolio, vaf = valor_atual_portfolio, rpp = retorno_percentual_portfolio, dpr = desvio_padrao_retornos)

@app.route("/navigate_portfolios", methods=["post"])
def navigate_portfolios():
    ulogin=session.get("user")
    action = request.form['action']
    return psub.all_portfolios(action=action, ulogin=ulogin)

prev_option = ""

@app.route("/Userlogin", methods=["post","get"])
def userlogin():
    global prev_option
    ulogin=session.get("user")
    if (ulogin != None):
        group = Userlogin.obj[ulogin].usergroup
        if group != "Manager":
            Userlogin.current(ulogin)
        butshow = "enabled"
        butedit = "disabled"
        option = request.args.get("option")
        if option == "edit":
            butshow = "disabled"
            butedit = "enabled"
        elif option == "delete":
            obj = Userlogin.current()
            Userlogin.remove(obj.user)
            if not Userlogin.previous():
                Userlogin.first()
        elif option == "insert":
            butshow = "disabled"
            butedit = "enabled"
        elif option == 'cancel':
            pass
        elif prev_option == 'insert' and option == 'save':
            obj = Userlogin(request.form["user"],request.form["usergroup"], \
                            Userlogin.set_password(request.form["password"]))
            Userlogin.insert(obj.user)
            Userlogin.last()
        elif prev_option == 'edit' and option == 'save':
            obj = Userlogin.current()
            if group == "Manager":
                obj.usergroup = request.form["usergroup"]
            if request.form["password"] != "":
                obj.password = Userlogin.set_password(request.form["password"])
                print(obj.password)
            Userlogin.update(obj.user)
        elif option == "first":
            Userlogin.first()
        elif option == "previous":
            Userlogin.previous()
        elif option == "next":
            Userlogin.nextrec()
        elif option == "last":
            Userlogin.last()
        elif option == 'exit':
            return render_template("index.html", ulogin=session.get("user"), group="Manager")
        prev_option = option
        obj = Userlogin.current()
        if option == 'insert' or len(Userlogin.lst) == 0:
            user = ""
            usergroup = ""
            password = ""
        else:
            user = obj.user
            usergroup = obj.usergroup
            password = ""
        return render_template("userlogin.html", group="Manager",ulogin=session.get("user"), butshow=butshow, butedit=butedit, user=user,usergroup = usergroup,password=password)
    else:
        return render_template("index.html", ulogin=ulogin, group="Manager")

@app.route("/Portfolio/<phone>", methods=["post","get"])
def portfolio(phone): 
    ulogin=session.get("user")
    group = None
    client_name = None
    if ulogin != None:
            group = Userlogin.obj[ulogin].usergroup
            if group == "Client":
                client_name = Userlogin.obj[ulogin].user
    if (ulogin != None):
        for p in Portfolio.obj:
            if Portfolio.obj[p].client == client_name:
                portfolio=Portfolio.obj[p]
    if portfolio:
        df, valor_total_portfolio, valor_atual_portfolio, portfolio_por_tipo_ativo, resumo_por_tipo_ativo, retorno_percentual_portfolio, desvio_padrao_retornos,pie_url,time_series_url = Portfolio.estatisticas(portfolio)
        transactions = df.to_dict('records')
        table_html = df.to_html(classes='table table-striped', index=False)
        return render_template("portfolio.html", portfolio=portfolio, transactions=transactions,
                               valor_total_portfolio=valor_total_portfolio, valor_atual_portfolio=valor_atual_portfolio,
                               resumo_por_tipo_ativo=resumo_por_tipo_ativo, retorno_percentual_portfolio=retorno_percentual_portfolio,
                               desvio_padrao_retornos=desvio_padrao_retornos,balance=portfolio.balance,
                               manager=portfolio.manager, group = 'Client', ulogin = ulogin, phone=phone,
                               df=df,table=table_html,pie_url=pie_url,time_series_url=time_series_url)
    else:
        return "Portfolio not found", 404
    return tsub.open_positions(phone=phone)

@app.route("/transactions/<phone>", methods=["post","get"])
def transactions(phone):    
    if request.method == "POST":
        quantidade = float(request.form.get("quantidade"))
        assets_code = str(request.form.get("assets_code"))
        ulogin=session.get("user")
        group = None
        client_name = None
        if ulogin != None:
                group = Userlogin.obj[ulogin].usergroup
                if group == "Client":
                    client_name = Userlogin.obj[ulogin].user
        if (ulogin != None):
            for p in Portfolio.obj:
                if Portfolio.obj[p].client == client_name:
                    portfolio=Portfolio.obj[p]
        if portfolio:
            port_code = portfolio.code
            asset_found = False
            for class_name in [Stock, ETF, Commodity, Cryptocurrency]:
               if assets_code in class_name.available_assets:
                  asset = next((a for a in class_name.obj.values() if a.ticker == assets_code), None)
                  if asset:
                      asset.update_price()
                      asset_found = True
                      break
            if not asset_found:
                      return "Asset not found", 404
            transaction = Transaction(None, datetime.datetime.now(), quantidade, assets_code, port_code)
            Portfolio.add_transaction(portfolio,transaction)
            return redirect(url_for("portfolio", code=port_code, group = 'Client', phone=phone, asset = asset))
        else:
            return "Portfolio not found", 404
    ulogin=session.get("user")
    group = None
    client_name = None
    if ulogin != None:
             group = Userlogin.obj[ulogin].usergroup
             if group == "Client":
                 client_name = Userlogin.obj[ulogin].user
    if (ulogin != None):
         for p in Portfolio.obj:
             if Portfolio.obj[p].client == client_name:
                 portfolio=Portfolio.obj[p]  
    return render_template("transactions.html", group = 'Client', phone = phone)

@app.route("/send_message", methods=["GET", "POST"])
def send_message():
    if request.method == "POST":
        message = request.form["message"]
        receiver_code = request.form["receiver_code"]
        sender_code = session.get("user")
        if sender_code and receiver_code:
            notification = Notification.send_message(message, sender_code, receiver_code)
            Notification.receive_message(notification)
    return render_template("send_message.html",group="Manager",ulogin=session.get("user"))

@app.route("/view_messages")
def view_messages():
    ulogin = session.get("user")
    received_msgs = [msg for msg in Notification.received_messages.values() if msg.receiver_code == ulogin]
    return render_template("view_messages.html", messages=received_msgs, group='Company',ulogin=ulogin, company_name = ulogin)


@app.route("/portfolio")
def show_portfolio():
    df, valor_total_portfolio, valor_atual_portfolio, portfolio_por_tipo_ativo, resumo_por_tipo_ativo, retorno_percentual_portfolio, desvio_padrao_retornos, pie_chart, line_chart = portfolio.estatisticas()
    table_html = df.to_html(classes='table table-striped', index=False)
    return render_template("portfolio.html", table=table_html, valor_total_portfolio=valor_total_portfolio,
                           valor_atual_portfolio=valor_atual_portfolio, resumo_por_tipo_ativo=resumo_por_tipo_ativo,
                           retorno_percentual_portfolio=retorno_percentual_portfolio, desvio_padrao_retornos=desvio_padrao_retornos,
                           pie_chart=pie_chart, line_chart=line_chart)

if __name__ == '__main__':
    app.run(debug=True)
    #app.run()
    
